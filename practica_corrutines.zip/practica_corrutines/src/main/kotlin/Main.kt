import kotlinx.coroutines.*
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.flow.map

//= runBlocking<Unit>
fun main(args: Array<String>)= runBlocking<Unit>{
    println("Práctica de courutines!")
 //lateinit var job
    val job =GlobalScope.launch{
        var ciudades=listOf("madrid","sevilla","valencia","ávila","córdoba","granada")
        //ciudades.asFlow().collect{print(it)}
        flow{
            ciudades.map {ciudad->
                emit(ciudad)
                delay(100)
            }
        }.collect{println(it)}
       // ciudades.asFlow().map { ciudad->emit(ciudad) }
    }

    val job2=GlobalScope.launch{
        var ciudades=listOf("paris","marsella","burdeos","orleans","nantes","montpellier")
        //ciudades.map{ciudad ->println(ciudad)}
        flow{
            ciudades.map {ciudad->
                emit(ciudad)
                delay(200)
            }
        }.collect{println(it)}
    }
   // Thread.sleep(1000)
    job.join()
   job2.join()

    // Try adding program arguments via Run/Debug configuration.
    // Learn more about running applications: https://www.jetbrains.com/help/idea/running-applications.html.
    //println("Program arguments: ${args.joinToString()}")



}