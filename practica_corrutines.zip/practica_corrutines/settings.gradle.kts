
rootProject.name = "practica_corrutines"

