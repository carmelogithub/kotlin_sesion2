package com.mindorks.kotlinFlow.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}