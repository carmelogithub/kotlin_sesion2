package com.lukaslechner.coroutineusecasesonandroid.utils

class EndpointShouldNotBeCalledException : Throwable()